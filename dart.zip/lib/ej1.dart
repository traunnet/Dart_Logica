//Obtener el promedio de edad de tres personas.

void main() {
  int edad1 = 25;
  int edad2 = 30;
  int edad3 = 35;

  double promedio = (edad1 + edad2 + edad3) / 3;
  print("===============================");
  print("El promedio de edad es: $promedio");
  print("===============================");
}
