package com.example.mixto

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
