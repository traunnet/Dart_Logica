package com.example.mixto2

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
